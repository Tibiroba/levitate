<?php get_header(); ?>



<!-- <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner" role="listbox">
    
    <div class="carousel-item active" style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/img/cta1.jpg')">
      <div class="carousel-caption d-none d-md-block">



      </div>
    </div>
    
    <div class="carousel-item" style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/img/cta2.jpg')">
      <div class="carousel-caption d-none d-md-block">

      </div>
    </div>
    
    <div class="carousel-item" style="background-image: url('<?php echo get_stylesheet_directory_uri(); ?>/img/cta3.jpg')">
      <div class="carousel-caption d-none d-md-block">

      </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div> -->



<div class="content">


  <div class="container-fluid  h-100" id="firstSection">

    <div class="row banner">
      <div class="col-6">


        <div class="ctaText h-100">
          <ul>
            <li>
              <h1 style="color:white;">Sinta-se leve e confiante com Levitate</h1>
            </li>
            <li>
              <p>Você mecere um desodorante eficaz e seguro para pele de todo o corpo</p>
            </li>
            <li><button class="btn btnPink">Experimente Levitate</button></li>
          </ul>



        </div>


      </div>
      <div class="col-6">
        <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/PRODUTO_BANNER.png" alt="">
      </div>

    </div>

    <div class="row whiteRow">
      <div class="col-6">
  <img src="<?php echo get_stylesheet_directory_uri();?>/img/MULHERSALTANDO.png" alt="">
      </div>
      <div class="col-6">
        <h2>Loção Antiodores Levitate</h2>
        <p>Poderrosamente segura e eficaz para ser usada no corpo todo!</p>
        <ul>
          <li>Axilas</li>
          <li>Bumbum</li>
          <li>Pés</li>
          <li>Seios</li>
          <li>Pescoço</li>
          <li>Virilhas</li>
          <li>e mais!</li>
        </ul>
        <button class="btn btnPink">Experimente Levitate</button>
      </div>
    </div>


    <div class="row h-100">
      <div class="col-6 whiteRow">
        <h3>Bloquea odor por 24 horas</h3>
        <p>Leve aonde for, e como auxílio do <strong>Lenço Levitate</strong>, como um banho a seco você pode higienizar qualquer parte do corpo que desejar</p>
        <img src="<?php echo get_stylesheet_directory_uri(  );?>/img/MULHER.png" alt="">
      </div>
      <div class="col-6" style="">
        <div class="boxNuvem">
          <img src="<?php echo get_stylesheet_directory_uri() ?>/img/NUVEM_03.png" alt="">
          <h4>Em qualquer hora do dia</h4>
          <p>Ao acordar, depois da academia, quando surge uma reunião ou um encontro inesperado</p>
          <button class="btn btnPink">Experimente Levitate</button>
        </div>
      </div>
    </div>

    <div class="row bgRoxo">
      <div class="col-8">
        <h3>Fórmula baseada em estudos científicos</h3>
        <p>Com eficácia e segurança comprovadas</p>
      </div>

      <div class="col-4">
        <img src="<?php echo get_stylesheet_directory_uri() ?>/img/CHECK_ICONE.png" alt="">
      </div>
    </div>

    <div class="row greyBg">
      <div class="col-6">
        <p>A <strong>Água Micelar levitate</strong>foi desenvolvida por uma equipe de médicos e aprimorada pelos alunos e professores da <b>Famra junior</b><a href="#">(Saiba mais)</a></p>
        <button class="btn btnPink">Experimente Levitate</button>

      </div>

      <div class="col-6">
        <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/CIENTISTA.png" alt="">
      </div>
    </div>

    <div class="row whiteRow">
      <div class="col-12">
        <p>Super dicas de Higienização Corporal para que você tenha segurança de que não passará por situações desagradáveis</p>

        <ul class="listaCard">
          <li>
            <div class="card">
              <img width="50px" src="<?php echo get_stylesheet_directory_uri();?>/img/ICONEAXILA.png" alt="">
              <span>Bromidrose nas axilas</span>
            </div>
          </li>
          <li>
            <div class="card">
              <img width="50px" src="<?php echo get_stylesheet_directory_uri();?>/img/ICONEFEMININO.png" alt="">
              <span>Higiene Feminina</span>
            </div>
          </li>
          <li>
            <div class="card">
              <img width="50px" src="<?php echo get_stylesheet_directory_uri ();?>/img/ICONEMASCULINO.png" alt="">
              <span>Higiene Masculina</span>
            </div>
          </li>
        </ul>
      </div>
    </div>

    <div class="row bgRoxo">
      <p>Como a Água Micelar Antiodores Levitate funciona?</p>
    </div>

    <div class="row whiteRow">
        <p>Nossa fórmula contém <b>tensoativos suaves</b>, que <b>removem as impurezas</b> da pele.</p>
        <p>Ela bloqueia a formação de odores através dos ativos:</p>
        <div class="col-6">
  <p>Symdeo B125</p>
  <span>Combate as bactérias causadras dos odores;</span>
  <p>Trietilcitrato</p>
  <span>Tem ação enzimática que impede a decomposição do suor.</span>
        </div>
        <div class="col-6">
        <img src="<?php echo get_stylesheet_directory_uri();?>/img/ICONEQUIMICA.png" alt="">
        </div>

    </div>
    

    <div class="row bgRoxo">
  <p>Componentes selecionados, até para a pele mais sensível</p>
    </div>

    <div class="row whiteRow">
        <div class="col-4">
        <img src="<?php echo get_stylesheet_directory_uri ();?>/img/MULHERSORRINDO.png" alt="">
        </div>

        <div class="col-8">
          <ul class="customList">
            <li>
            <p>Niacinamida</p>
              <span>Clareia e uniformiza o tom da pele;</span>
            </li>
            <li>
            <p>Ácido lático</p>
              <span>Regula o Ph cutâneo;</span>
            </li>
            <li>
            <p>D'Pantenol, Óleo de coco e extrato de Aloe Vera</p>
              <span>Acalmam e coonferem hidratação.</span>
            </li>
              
          </ul>
        </div>
    </div>

    <div class="row blueBg">
        <p>Água Micelar Levitate<br><b>Primeira e Única no Brasil</b></p>
        <span><b>Levitate</b> mudou a forma de lidarmos com odores corporais</span>
        <span>Opção de <strong>higiene rápida</strong> que pode ser usada no corpo todo e <b>previne odores.</b></span>
        <p>Por que você merece estar leve e confiante o dia todo!</p>
    </div>

    <div class="row bgRoxo">

    <ul>
      
      <li><img src="<?php echo get_stylesheet_directory_uri(  );?>/img/ICONE_DERMATOLOGICAMENTETESTADO.png" alt=""></li>
      <li><img src="<?php echo get_stylesheet_directory_uri(  );?>/img/ICONE_ACEITABILIDADE.png" alt=""></li>
      <li><img src="<?php echo get_stylesheet_directory_uri(  );?>/img/ICONE_HIPOALERGENICA.png" alt=""></li>
      <li><img src="<?php echo get_stylesheet_directory_uri(  );?>/img/ICONE_ROUPAS.png" alt=""></li>
      <li><img src="<?php echo get_stylesheet_directory_uri(  );?>/img/ICONE_VEGAN.png" alt=""></li>
      <li><img src="<?php echo get_stylesheet_directory_uri(  );?>/img/ICONE_ALUMINIO.png" alt=""></li>
    </ul>

    </div>


  </div>







</div>



<?php get_footer(); ?>