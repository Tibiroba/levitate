<footer id="footer">
   
   <div class="container">
      <div class="row">
         
      </div>
   </div>


</footer>

<?php wp_footer(); ?>
</body>
</html>

